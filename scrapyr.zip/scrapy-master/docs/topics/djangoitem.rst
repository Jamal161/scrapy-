:orphan:

.. _topics-djangoitem:

==========
DjangoItem
==========

DjangoItem has been moved into a separate project.

It is hosted at:

    https://github.com/scrapy-plugins/scrapy-djangoitem
