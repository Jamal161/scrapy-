EXTENSIONS = {
    'tests.test_cmdline.extensions.TestExtension': 0,
}

TEST1 = 'default'
